# uds-tailwind-test

`uds-tailwind-test` is a publishable React UI package built from this Tailwind v4 and shadcn-based design system workspace.

This package contains three kinds of exports:

- themed primitive wrappers
- UDS preset wrappers
- first-party system components

The important rule for consumers and AI tools is simple: import only from `uds-tailwind-test` and `uds-tailwind-test/styles.css`.

## Installation

```bash
npm install uds-tailwind-test react react-dom
```

Import the stylesheet once near your app root:

```ts
import "uds-tailwind-test/styles.css"
```

## Quick Start

```tsx
import {
  Button,
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "uds-tailwind-test"
import "uds-tailwind-test/styles.css"

export function Example() {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button>Open</Button>
        </TooltipTrigger>
        <TooltipContent>Package quick start</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
```

## CSS Contract

`uds-tailwind-test/styles.css` is the canonical consumer stylesheet.

It currently imports:

- Tailwind v4 base utilities
- `tw-animate-css`
- the package token layer
- the package component layer

Dark mode follows the existing `.dark` class convention on the root element.

Consumers may override the shipped CSS variables with their own values. Fonts are optional. The docs app imports additional font assets, but package consumers can load their own typography stack.

## Public API Model

The root package entrypoint is [src/index.ts](./src/index.ts). That file is the only canonical public API.

Internal implementation layers such as these are not public API:

- `*-base.tsx`
- `*-core.tsx`
- `*-theme.ts`
- `*-theme.tsx`
- `*-uds.tsx`

They exist to keep the system maintainable. Consumers should not import from them.

### Primitive Wrappers

Examples:

- `Button`
- `Drawer`
- `Pagination`
- `Command`
- `Combobox`

These are package-facing wrappers around lower-level primitives.

### UDS Preset Wrappers

Examples:

- `AlertDialog`
- `Dialog`
- `Sheet`
- `Avatar`
- `NavigationMenu`

These represent the UDS-styled package surface. Their internal implementation may compose base primitives, but consumers should still import them from `uds-tailwind-test`.

### First-Party System Components

Examples:

- `AppShell`
- `Item`
- `FileUpload`
- `FileUploadCards`
- `Sidebar`
- `ChartContainer`

These are original components in this system, not just themed shadcn wrappers.

## AI Usage

If you are using this package with an AI code generator, give it these rules:

1. Import components only from `uds-tailwind-test`.
2. Import styles only from `uds-tailwind-test/styles.css`.
3. Do not import from internal files such as `uds-tailwind-test/dist/*`, `src/components/ui/*`, or any `*-base`, `*-core`, `*-theme`, or `*-uds` module.
4. Treat `AppShell`, `Sidebar`, `Item`, `FileUpload`, `FileUploadCards`, and `ChartContainer` as first-party components, not stock shadcn primitives.
5. Treat the package root exports as the source of truth for available components.
6. For authenticated application screens, default to `AppShell` unless the user explicitly requests a different layout.
7. When using `AppShell`, prefer the theme `Sidebar` primitives for the `sidebar` region and only include the `listview` or `footer` regions when the screen needs them.

For a dedicated AI-oriented guide, see [AI_USAGE.md](./AI_USAGE.md).

## Docs-Only Exceptions

These are intentionally not part of the published component contract:

- `Branding`
- `DoctorAvatar`

They depend on repo-owned assets and docs-specific assumptions.

## Local Development

```bash
npm install
npm run dev
```

Useful checks:

```bash
npm run lint
npm run typecheck
npm run build
npm run pack:check
```

The docs app builds to `docs-dist/`. The package build emits distributable artifacts to `dist/`.

## Consumer Smoke Fixture

A minimal consumer example lives in [examples/consumer-react](./examples/consumer-react). It demonstrates the intended import shape:

- package imports from `uds-tailwind-test`
- stylesheet import from `uds-tailwind-test/styles.css`

## Publishing

- `npm run build` builds both the package and the docs app.
- `npm run pack:check` verifies the publish payload.
- published exports are defined in [package.json](./package.json).
