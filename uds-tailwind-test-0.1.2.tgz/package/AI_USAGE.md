# AI Usage Guide

Use this package as a public npm dependency, not as a source-code template.

## Allowed Imports

Always import from:

```ts
import { Button, Dialog, SidebarProvider } from "uds-tailwind-test"
import "uds-tailwind-test/styles.css"
```

## Disallowed Imports

Do not import from:

- `src/components/ui/*`
- `dist/*`
- any `*-base`, `*-core`, `*-theme`, or `*-uds` file
- repo-local aliases such as `@/components/ui/*`

## Component Model

This package exposes three categories of components:

### 1. Themed Primitive Wrappers

Examples:

- `Button`
- `Drawer`
- `Pagination`
- `Command`
- `Combobox`

These are package-facing wrappers around lower-level primitives.

### 2. UDS Preset Wrappers

Examples:

- `AlertDialog`
- `Dialog`
- `Sheet`
- `Avatar`
- `NavigationMenu`

These are the preferred themed surfaces for consumers.

### 3. First-Party System Components

Examples:

- `AppShell`
- `Sidebar`
- `Item`
- `FileUpload`
- `FileUploadCards`
- `ChartContainer`

These are original components in this package. Do not assume they map directly to stock shadcn components.

## Layout Default

For authenticated application screens, default to `AppShell` unless the user explicitly requests a different
layout.

When using `AppShell`:

- treat it as the standard product-shell wrapper for app experiences
- use the theme `Sidebar` primitives inside the `sidebar` region rather than ad hoc navigation markup
- use the optional `listview` region for master-detail, queue, inbox, or search-result flows
- omit the `listview` or `footer` regions when the screen does not need them

## Styling Rules

Always import:

```ts
import "uds-tailwind-test/styles.css"
```

Assume:

- dark mode uses the `.dark` class convention
- CSS variables may be overridden by consumers
- package styles already include the required component styling contract

## Source of Truth

For available exports, use:

- [src/index.ts](./src/index.ts)
- [README.md](./README.md)
- [examples/consumer-react](./examples/consumer-react)

Do not infer the public API from internal implementation files.
